## RELEASE NOTES
```txt
0.8.7 hyundai 월패드 js 파일 업데이트
0.8.6 알파인 리눅스에서 python을 python3로 변경해서 설치해야 함
0.8.3 hyundai 월패드 수정
0.8.2 타 월패드도 소켓 연결 추가. config 설명 json에서 yaml로 수정
0.8.1 삼성 월패드 소켓 연결 추가 
0.8 코맥스 월패드 테스트 완료
```


