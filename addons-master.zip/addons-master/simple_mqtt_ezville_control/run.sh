#!/bin/sh

PY_FILE="ezville.py"

# start server
echo "[Info] Start simple_mqtt_ezville_control"

python -u /$PY_FILE
